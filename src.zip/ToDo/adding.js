import React from "react";
import './App.css';

const Task = () => {

    const [ isEditing, setEditing ] = React.useState( false );
    const [ task, setTask ] = React.useState( '' );
    const [ final, setFinal ] = React.useState( [] )
    const [ radio, setRadio ] = React.useState( 'incomplete' );
    const [ edit, setEdit ] = React.useState( -1 );
    //the index is set to -1 indicate that no task is currently being edited as no value has index -1

    //allow data editing
    const handleEdit = () => {
        setEditing( true )
    }

    //create a value for task variable
    const makeChange = ( event ) => {
        if( isEditing === true ){
            setTask( event.target.value )
        }
    }

    //save the task to 'final'
    const save = () => {
        setFinal( ( prevFinal ) => [ ...prevFinal, task ] );
        setTask( '' )
        setEditing( false )
    }

    //deleting a task
    const deleteTask = ( i ) => {
        //new array finals is assigned all values of final
        setFinal( (prevFinal) => {
            const finals = [ ...prevFinal ];
            //.splice function is used to remove the value with given index
            finals.splice( i, 1 );
            return finals;
        } )
    }

    //editing a task
    const editTask = ( i ) => {
        //open editing mode
        setEditing( true );
        //set the index for the editing effects
        setEdit( i );
    }

    const update = () => {
        //making a copy of array Final
        setFinal( ( prevFinal ) => {
            const updated = [ ...prevFinal ];
            //setting the new value to task
            updated[ edit ] = task;
            //return the new value
            return updated;
        } )
        setTask( '' );
        setEdit();
        setEditing( false );
    }

    //change the value of radio button
    const changeRadio = ( event ) => {
        setRadio( event.target.value );
    }

    return (
        <div>
            <h1>ToDo App</h1>
            <fieldset className="main">
                <label htmlFor="text">Type here:</label>
                <br />
                <input type="text" value = { task } onClick = { handleEdit } onChange = { makeChange } className="input" />
                <button onClick = { save } id="save">Add</button>
                <br />
                <table>
                    <thead>
                        <tr>
                            <th id="task">Tasks</th>
                            <th>Completed</th>
                            <th>In Progress</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* use map function to display all tasks */}
                        { final.map(( task, i ) => (
                            <tr key = { i }>
                                <td>{ task }</td>
                                <td>
                                    <input type="radio" className="complete" value="complete" checked = { radio === 'complete' } onClick = { changeRadio } />
                                </td>
                                <td>
                                    <input type="radio" className="incomplete" value="incomplete" checked = { radio === 'incomplete' } onClick = { changeRadio } />
                                </td>
                                <td>
                                    <button onClick = { () => editTask( i ) } id="edit" />
                                </td>
                                <td>
                                    <button onClick = { () => deleteTask( i ) } id="delete" />
                                </td>
                            </tr>
                        ) ) }
                    </tbody>
                </table>
            </fieldset>
        </div>
    )
}

export default Task;
